package sit.int204.classicmodelsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassicmodelsServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
