package sit.int204.classicmodelsservice.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import sit.int204.classicmodelsservice.entities.Employee;
import sit.int204.classicmodelsservice.entities.Office;
import sit.int204.classicmodelsservice.exeception.ItemNotFoundExeception;
import sit.int204.classicmodelsservice.repositories.EmployeeRepository;
import sit.int204.classicmodelsservice.repositories.OfficeRepository;

import java.util.List;
import java.util.Set;

@Service
public class OfficeService {
    @Autowired
    private OfficeRepository repository;
    @Autowired
    private EmployeeRepository employeeRepository;

    public Set<Employee> getEmployees(String officeCode){
        Office office = repository.findById(officeCode).orElseThrow(
                ()->new HttpClientErrorException(HttpStatus.NOT_FOUND, "Office Id"+ officeCode + "does not exist!!!"));
        return office.getEmployees();
    }


    public List<Office> getOffices(){
        return repository.findAll();
    }

    public Office getOffice(String officeCode){
        return repository.findById(officeCode).orElseThrow(
                ()->new ItemNotFoundExeception("Office Id " + officeCode + " does not exist!!!"));
    }

    public Office addNewOffice(Office newOffice){
        return repository.saveAndFlush(newOffice);
    }

    public Employee addEmployeeOffice(String officeCode, Employee newEmployee) {
        Office office = getOffice(officeCode);
        newEmployee.setOffice(office);
        return employeeRepository.saveAndFlush(newEmployee);
    }

}
