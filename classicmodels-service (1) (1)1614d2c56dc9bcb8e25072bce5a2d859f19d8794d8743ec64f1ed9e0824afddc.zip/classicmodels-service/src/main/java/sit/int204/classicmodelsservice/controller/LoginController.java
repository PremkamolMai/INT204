package sit.int204.classicmodelsservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.entities.Customer;
import sit.int204.classicmodelsservice.services.CustomerService;


@RequestMapping("/api/login")
@RestController
public class LoginController {
    @Autowired
    private CustomerService customerService;

//    @PostMapping("")
//    public ResponseEntity<Customer> login(@RequestBody LoginDTO loginDTO) {
//        Customer customer = customerService.login(loginDTO);
//        return new ResponseEntity<>(customer, HttpStatus.OK);
//    }

    @GetMapping("")
    public ResponseEntity<Customer> login(@RequestParam String customerName, @RequestParam String password ) {
        Customer customer = customerService.login(customerName,password);
        return new ResponseEntity<>(customer, HttpStatus.OK);
    }
}
