package sit.int204.classicmodelsservice.controller;

import lombok.Getter;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sit.int204.classicmodelsservice.dtos.PageDTO;
import sit.int204.classicmodelsservice.dtos.SimpleCustomerDTO;
import sit.int204.classicmodelsservice.entities.Customer;
import sit.int204.classicmodelsservice.repositories.CustomerRepository;
import sit.int204.classicmodelsservice.services.CustomerService;
import sit.int204.classicmodelsservice.utils.ListMapper;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CustomerService service;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListMapper listMapper;

//    @GetMapping("")
//    public List<Customer> getCustomer() {
//        return customerRepository.findAll();
//    }

    @GetMapping("")
    public List<SimpleCustomerDTO> getCustomers(){
        List<Customer> customersList = service.getCustomers();
        List<SimpleCustomerDTO> customersDTOList =
                customersList.stream().map(c -> modelMapper.map(c, SimpleCustomerDTO.class)).collect(Collectors.toList());
        return customersDTOList;
    }




    @GetMapping("/{customerId}")
    public SimpleCustomerDTO getSimpleCustomerById(@PathVariable Integer customerId) {
            return modelMapper.map(service.getCustomerById(customerId), SimpleCustomerDTO.class);
    }

    @GetMapping("/page")
    public PageDTO<SimpleCustomerDTO> getCustomersWithPagination(){
        Page<Customer> customerList = service.getCustomersWithPagination(0,5);
        return listMapper.toPageDTO(customerList, SimpleCustomerDTO.class, modelMapper);
    }
}
