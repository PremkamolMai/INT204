package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelsservice.entities.Customer;
import sit.int204.classicmodelsservice.repositories.CustomerRepository;

import java.util.List;


@Service
public class CustomerService {
    public List<Customer> getCustomers(){
        return repository.findAll();
    };
    @Autowired
    private CustomerRepository repository;
    public Customer getCustomerById(Integer customerId) {
        return repository.findById(customerId).orElseThrow(()->new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Customer id "+ customerId+ "Does Not Exist !!!"));
    }

    public Page<Customer> getCustomersWithPagination(int page, int size){
        return repository.findAll(PageRequest.of(page, size));
    }
    public Customer login(String customerName, String password) {
        Customer customer = repository.findCustomerByCustomerNameAndPassword(customerName, password).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Login Fail"));
        return customer;
    }
}