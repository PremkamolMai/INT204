package sit.int204.classicmodelsservice.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodelsservice.entities.Product;

import java.util.List;


public interface ProductRepository extends JpaRepository<Product, String> {
    List<Product> findProductByQuantityGreaterThanEqual(Integer quantity);

    Page<Product> findProductByQuantityGreaterThanEqual(Integer quantity, Pageable pageable);

    List<Product> findProductByProductNameContainingOrProductDescriptionContaining(String name, String description);

    Page<Product> findProductByProductNameContainingOrProductDescriptionContaining(String name, String description,Pageable pageable);

    List<Product> findProductsByPriceBetweenOrderByPriceDesc(Double low, Double high);

    List<Product> findProductsByProductLine(String line, Sort sort);




}
