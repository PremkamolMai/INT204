package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import sit.int204.classicmodelsservice.entities.Employee;
import sit.int204.classicmodelsservice.entities.Product;
import sit.int204.classicmodelsservice.repositories.ProductRepository;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public Page<Product> getProductWithpaging(int page, int size, String sortBy){
        Sort sort = Sort.by(sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return productRepository.findAll(pageable);
    }

    public List<Product> getProductsQuantity(int quantity){
        return productRepository.findProductByQuantityGreaterThanEqual(quantity);
    }


    public List<Product> getProductsByNameOrDescription(String name,String description){
        return productRepository.findProductByProductNameContainingOrProductDescriptionContaining(name, description);
    }

    public List<Product> getProductsByPriceBetween(double low,double high){
        if(low>high){
//            double tmp = low;
//            low = high;
//            high = tmp;
            return productRepository.findProductsByPriceBetweenOrderByPriceDesc(high, low);
        }else {
            return productRepository.findProductsByPriceBetweenOrderByPriceDesc(low, high);
        }

    }

    public List<Product> getProductsByProductLine(String line,String sortBy){
        Sort sort = Sort.by(sortBy);
        return productRepository.findProductsByProductLine(line, sort);

    }

    public Product updateProducts(String productCode, Product updateProduct){
        Product product = productRepository.findById(productCode).orElseThrow(
                ()->new ResourceNotFoundException(productCode + "does not exist!!!"));
        product.setProductName(updateProduct.getProductName());
        product.setProductLine(updateProduct.getProductLine());
        product.setProductScale(updateProduct.getProductScale());
        product.setProductVendor(updateProduct.getProductVendor());
        product.setProductDescription(updateProduct.getProductDescription());
        product.setQuantity(updateProduct.getQuantity());
        product.setBuyPrice(updateProduct.getBuyPrice());
        product.setPrice(updateProduct.getPrice());
        return productRepository.saveAndFlush(product);
    }

    public Product addNewProduct(Product newProduct){
        return productRepository.saveAndFlush(newProduct);
    }


}
