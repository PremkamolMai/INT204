package sit.int204.classicmodelsservice.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.dtos.SimpleEmployeeDTO;
import sit.int204.classicmodelsservice.entities.Employee;
import sit.int204.classicmodelsservice.repositories.EmployeeRepository;
import sit.int204.classicmodelsservice.services.EmployeeService;

import java.util.List;
import java.util.stream.Collectors;


@RestController
    @RequestMapping("/api/employees")
    public class EmployeeController {
        @Autowired
        private EmployeeService service;

        @Autowired
        private EmployeeRepository repository;

        @Autowired
        private ModelMapper modelMapper;

//        @GetMapping("")
//        public List<Employee> getEmployees(){return service.getAllEmployees();}

        @GetMapping("")
        public List<SimpleEmployeeDTO> getEmployees() {
            List<Employee> employeeList = repository.findAll();
            return employeeList.stream()
                    .map(e -> modelMapper.map( e, SimpleEmployeeDTO.class))
                    .collect(Collectors.toList());
        }

        @GetMapping("/{employeeNumber}")
        public Employee getEmployee(@PathVariable int employeeNumber){
            return service.getEmployee(employeeNumber);
        }

        @PutMapping("/{employeeNumber}")
        public Employee updateEmployee(@PathVariable int employeeNumber, @RequestBody Employee updateEmployee){
            if (employeeNumber == updateEmployee.getId()) {
                return service.updateEmployee(employeeNumber, updateEmployee);
            } else {
                throw new RuntimeException("EmployeeNumber is not match !!!");
            }
        }

        @DeleteMapping("/{employeeNumber}")
        public void deleteEmployee(@PathVariable int employeeNumber){
            service.deleteEmployee(employeeNumber);
        }


    }
