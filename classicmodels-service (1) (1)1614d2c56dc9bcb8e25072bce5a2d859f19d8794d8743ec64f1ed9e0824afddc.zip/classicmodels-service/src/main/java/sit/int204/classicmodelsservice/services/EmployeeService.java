package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import sit.int204.classicmodelsservice.entities.Employee;
import sit.int204.classicmodelsservice.repositories.EmployeeRepository;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository repository;

    public List<Employee> getAllEmployees(){
        return repository.findAll();
    }

    public Employee getEmployee(int employeeNumber){
        return repository.findById(employeeNumber).orElseThrow(
                ()->new ResourceNotFoundException(employeeNumber + "does not exist!!!"));
    }


    public Employee updateEmployee(int employeeNumber, Employee updateEmployee){
        Employee employee = repository.findById(employeeNumber).orElseThrow(
                ()->new ResourceNotFoundException(employeeNumber + "does not exist!!!"));
        employee.setFirstName(updateEmployee.getFirstName());
        employee.setLastName(updateEmployee.getLastName());
        employee.setExtension(updateEmployee.getExtension());
        employee.setEmail(updateEmployee.getEmail());
        employee.setReportsTo(updateEmployee.getReportsTo());
        employee.setJobTitle(updateEmployee.getJobTitle());
        return repository.saveAndFlush(employee);
    }


    public void deleteEmployee(int employeeNumber){
        repository.deleteById(employeeNumber);
    }
}
