package sit.int204.classicmodelsservice.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.entities.Product;
import sit.int204.classicmodelsservice.services.ProductService;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductControllor {
    @Autowired
    private ProductService service;

    @GetMapping("/pages")
    public Page<Product> getProductsPage(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(defaultValue = "productCode") String sortBy){
        return service.getProductWithpaging(page, size, sortBy);
    }


    @GetMapping("")
    public List<Product> getProducts(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(defaultValue = "productCode") String sortBy){
        return service.getProductWithpaging(page, size, sortBy).getContent();
    }


    @GetMapping("/quantities/{quantity}")
    public List<Product> getProducts(@PathVariable Integer quantity){
        return service.getProductsQuantity(quantity);
    }

    @GetMapping("/filters")
    public List<Product> getProductsFilter(@RequestParam() String productName,@RequestParam() String productDescription){
        return service.getProductsByNameOrDescription(productName,productDescription);
    }

    @GetMapping("/prices/{min}/{max}")
    public List<Product> getProductsFilter(@PathVariable Double min,@PathVariable Double max){
        return service.getProductsByPriceBetween(min,max);
    }

    @GetMapping("/{ProductLine}")
    public List<Product> getProductsByProductLineByShip(@PathVariable String ProductLine,@RequestParam(defaultValue = "productCode") String sortBy){
        return service.getProductsByProductLine(ProductLine,sortBy);
    }


    @PutMapping("/{productCode}")
    public Product updateProduct(@PathVariable String productCode, @RequestBody Product updateProduct){
        return service.updateProducts(productCode, updateProduct);

    }

    @PostMapping("")
    public Product addProduct(@RequestBody Product product){
        return service.addNewProduct(product);
    }
}
