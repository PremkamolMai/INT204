package int204.sit.int204_lab_64130500108.controller;

import int204.sit.int204_lab_64130500108.dtos.SimpleOrderDTO;
import int204.sit.int204_lab_64130500108.entities.Order;
import int204.sit.int204_lab_64130500108.repository.CustomerRepository;
import int204.sit.int204_lab_64130500108.repository.OrderRepository;
import int204.sit.int204_lab_64130500108.services.CustomersService;
import int204.sit.int204_lab_64130500108.services.OrdersService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/64130500108/orders")

public class OrderController {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private OrdersService service;
    @Autowired
    private ModelMapper modelMapper;

    @GetMapping("")
    public List<SimpleOrderDTO> getOrder(){
        List<Order> orderList = service.getOrders();
        List<SimpleOrderDTO> orderDTOList =
                orderList.stream().map(o -> modelMapper.map(o,SimpleOrderDTO.class))
                        .collect(Collectors.toList());
        return orderDTOList;
    }

    @PostMapping("")
    public Order create(@RequestBody Order newOrder){
        return service.addNewOrder(newOrder);
    }

    @PutMapping("{orderNumber}")
    public Order updateOrder(@PathVariable int orderNumber,
                             @RequestBody Order updateOrder){
        if (orderNumber == updateOrder.getOrderNumber()) {
            return service.updateOrder(orderNumber, updateOrder);
        }else {
            throw new RuntimeException("OrderNumber is not match!!");
        }
    }
    @DeleteMapping("/{orderNumber}/customer")
    public void deleteOrder(@PathVariable int orderNumber){
        service.deleteOrder(orderNumber);
    }


}
