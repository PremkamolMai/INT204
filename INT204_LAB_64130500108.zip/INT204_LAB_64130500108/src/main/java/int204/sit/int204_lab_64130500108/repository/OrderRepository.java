package int204.sit.int204_lab_64130500108.repository;

import int204.sit.int204_lab_64130500108.entities.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Integer> {


}
