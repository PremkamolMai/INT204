package int204.sit.int204_lab_64130500108.services;

import int204.sit.int204_lab_64130500108.entities.Customer;
import int204.sit.int204_lab_64130500108.repository.CustomerRepository;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Getter
@Setter
public class CustomersService {
    @Autowired
    private CustomerRepository repository;

    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }


}
