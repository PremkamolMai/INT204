package int204.sit.int204_lab_64130500108.controller;

import int204.sit.int204_lab_64130500108.repository.CustomerRepository;
import int204.sit.int204_lab_64130500108.services.CustomersService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/64130500108/customers")
public class CustomerConTroller {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CustomersService service;
    @Autowired
    private ModelMapper modelMapper;


}
