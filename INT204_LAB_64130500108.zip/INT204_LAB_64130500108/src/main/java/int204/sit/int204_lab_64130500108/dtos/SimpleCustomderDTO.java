package int204.sit.int204_lab_64130500108.dtos;

public class SimpleCustomderDTO {
    private String customerNumber;
    private String customerFirstName;
    private String customerLastName;

    public String getName(){
        return customerFirstName + " "+ customerLastName;
    }
}
