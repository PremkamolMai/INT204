package int204.sit.int204_lab_64130500108.repository;

import int204.sit.int204_lab_64130500108.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
}
