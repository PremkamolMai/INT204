package int204.sit.int204_lab_64130500108.dtos;

import lombok.Getter;
import lombok.Setter;
import net.minidev.json.annotate.JsonIgnore;

@Getter
@Setter
public class SimpleOrderDTO {
    private String orderNumber;
    private String orderDate;
    private String status;

    private String salesRepCustomerNumber;
    private String salesRepCustomerFirstName;
    private String salesRepCustomerLastName;

    @JsonIgnore
    private SimpleCustomderDTO sales;
    public String getSalesPerson(){
        return sales == null ? "-" : sales.getName();
    }
}
