package int204.sit.int204_lab_64130500108.services;

import int204.sit.int204_lab_64130500108.entities.Order;
import int204.sit.int204_lab_64130500108.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;

import java.util.List;

public class OrdersService {
    @Autowired
    private OrderRepository repository;

    public List<Order> getOrders(){
        return repository.findAll();
    }
    public Order getOrder(int orderNumber){
        return repository.findAll(orderNumber).orElseThow(
                ()-> new ResourceNotFoundException(orderNumber + "does not exist"));
    }
    public Order addNewOrder(Order newOrder) {
        return OrderRepository.saveAndFlush(newOrder);
    }
    public Order updateOrder(int orderNumber,Order updateOrder){
        Order order = repository.findById(orderNumber).orElseThrow(
                () -> new ResourceNotFoundException(orderNumber + "does not exist !!"));
        order.setOrderNumber(updateOrder.getOrderNumber());
        order.setOrderDate(updateOrder.getOrderDate());
        order.setRequiredDate(updateOrder.getRequiredDate());
        order.setStatus(updateOrder.getStatus());
        order.setComments(updateOrder.getComments());
        order.setShippedDate(updateOrder.getShippedDate());
        return repository.saveAndFlush(order);
    }
    public void deleteOrder(int orderNumber) {
        repository.deleteById(orderNumber);

    }
}
