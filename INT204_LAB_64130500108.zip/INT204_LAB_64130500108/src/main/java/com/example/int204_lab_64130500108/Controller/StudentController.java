package com.example.int204_lab_64130500108.Controller;

import com.example.int204_lab_64130500108.entities.Student;
import com.example.int204_lab_64130500108.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("api/students")
public class StudentController {
    @Autowired
    private StudentService service;

    @GetMapping("")
    public List<Student> getStudent(){
        return  service.getAllStudent();
    }
    @ExceptionHandler(ItemNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ItemNotFoundException handleNoSuchElementFoundException(
            ItemNotFoundException exception) {
        return exception;
    }
    @ExceptionHandler(NumberFormatException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseStatusException handleNumberElementFoundException(RuntimeException exception){
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid number ja"+ exception.getMessage());
    }

}
