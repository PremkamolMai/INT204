package com.example.int204_lab_64130500108.dtos;

public class SimpleStudentGradeDTO {
}
