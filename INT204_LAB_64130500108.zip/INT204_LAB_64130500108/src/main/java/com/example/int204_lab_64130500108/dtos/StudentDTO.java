package com.example.int204_lab_64130500108.dtos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StudentDTO {
    private Integer studentId;
    private String name;
    @JsonIgnore
    private SimpleStudentGradeDTO studentgrade;

}
