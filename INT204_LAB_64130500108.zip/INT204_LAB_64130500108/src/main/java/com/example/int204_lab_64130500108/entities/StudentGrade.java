package com.example.int204_lab_64130500108.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;
@Entity
@Getter
@Setter
@Table(name = "studentGrades")
public class StudentGrade {
    @Id
    @Column(name = "gradeId",nullable = false,length = 10)
    private Integer id;
    @Column(name = "grade",nullable = false,length = 100)
    private Double grade;
    @JsonIgnore
    @OneToMany(mappedBy = "Subject")
    private Set<Subject> subjects = new LinkedHashSet<>();

}
