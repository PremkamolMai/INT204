package com.example.int204_lab_64130500108.service;

import com.example.int204_lab_64130500108.entities.Student;
import com.example.int204_lab_64130500108.repository.StudentRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class StudentService {
    @Autowired
    private StudentRepositories repositories;

    public List<Student> getAllStudent(){
    return repositories.findAll();
    }
}
