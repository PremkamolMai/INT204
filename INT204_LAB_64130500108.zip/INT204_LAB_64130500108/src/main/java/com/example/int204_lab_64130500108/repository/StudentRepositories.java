package com.example.int204_lab_64130500108.repository;

import com.example.int204_lab_64130500108.entities.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepositories extends JpaRepository<Student, Integer> {
}
