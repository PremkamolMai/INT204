package com.example.int204_lab_64130500108.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
@Entity
@Getter
@Setter
@Table(name = "subjects")
public class Subject {
    @Id
    @Column(name = "subjectId",nullable = false,length = 10)
    private Integer id;
    @Column(name = "studentCode",nullable = false,length = 100)
    private String code;
    @Column(name = "title",nullable = false,length = 100)
    private String title;
    @Column(name = "credit",nullable = false,length = 100)
    private Double credit;
}
