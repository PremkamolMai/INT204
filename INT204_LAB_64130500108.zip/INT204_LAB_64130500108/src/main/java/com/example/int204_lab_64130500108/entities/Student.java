package com.example.int204_lab_64130500108.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Table(name = "students")

public class Student {
    @Id
    @Column(name = "studentId",nullable = false,length = 10)
    private Integer id;
    @Column(name = "name",nullable = false,length = 100)
    private String name;
    @JsonIgnore
    @OneToMany(mappedBy = "StudentGrade")
    private Set<StudentGrade> studentGrades = new LinkedHashSet<>();

}
