package com.example.int204_lab_64130500108;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Int204Lab64130500108Application {

	public static void main(String[] args) {
		SpringApplication.run(Int204Lab64130500108Application.class, args);
	}

}
