package int204.sit.int204_lab_64130500108;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Int204Lab64130500108ApplicationTests {

    @Test
    void contextLoads() {
    }

}
