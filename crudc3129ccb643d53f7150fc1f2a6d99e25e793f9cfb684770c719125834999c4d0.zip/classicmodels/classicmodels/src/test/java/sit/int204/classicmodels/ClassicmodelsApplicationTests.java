package sit.int204.classicmodels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassicmodelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
