package sit.int204.classicmodels.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodels.DTO.EmployeeDto;
import sit.int204.classicmodels.entities.Employee;
import sit.int204.classicmodels.services.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("/api")

public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employees/getname/{a}")
    public List<Employee> findName(@PathVariable String a){
        return employeeService.getName(a);

    }
    @GetMapping("/employees")
    public List<EmployeeDto> find(){
        return employeeService.find();
    }
}
