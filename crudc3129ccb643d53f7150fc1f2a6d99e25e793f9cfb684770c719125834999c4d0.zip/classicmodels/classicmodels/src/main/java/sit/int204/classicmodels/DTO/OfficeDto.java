package sit.int204.classicmodels.DTO;


import lombok.Getter;
import lombok.Setter;
import sit.int204.classicmodels.entities.Employee;

import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
public class OfficeDto{
    private String phone;
    private String country;

    private List<EmployeeDto> employees;

}
