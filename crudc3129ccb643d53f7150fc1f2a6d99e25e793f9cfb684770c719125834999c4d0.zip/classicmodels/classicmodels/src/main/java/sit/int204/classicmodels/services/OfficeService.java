package sit.int204.classicmodels.services;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sit.int204.classicmodels.DTO.OfficeDto;
import sit.int204.classicmodels.ListMapper;
import sit.int204.classicmodels.entities.Employee;
import sit.int204.classicmodels.entities.Office;
import sit.int204.classicmodels.repository.OfficeRepository;

import java.util.List;
import java.util.stream.Collectors;


@Service

public class OfficeService {
    @Autowired
    private OfficeRepository officerepo;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListMapper listMapper;

    public List<Office> getAll() {
        return officerepo.findAll();
    }

    public Office getOfficeById(String officeCode) {
        return officerepo.findById(officeCode).orElseThrow(
                () -> new RuntimeException("can not find id ! "));
    }

    public List<Employee> getEmployeeById(String officeCode) {
        Office n = officerepo.findById(officeCode).orElseThrow(
                () -> new RuntimeException("cat not find id !!!"));
        return n.getEmployees();

    }

    public Office addOffice(Office office) {
        return officerepo.saveAndFlush(office);
    }

    public Office updateOffice(Office office, String officeCode) {
        Office m = officerepo.findById(officeCode).orElseThrow(
                () -> new RuntimeException("can not find id !!!"));
        m.setCity(office.getCity());
        m.setCountry(office.getCountry());
        m.setPhone(office.getPhone());
        return officerepo.saveAndFlush(m);
    }

    public Office delectOffice(String officeCode) {
        Office m = officerepo.findById(officeCode).orElseThrow(
                () -> new RuntimeException("can not find id !!!"));
        officerepo.delete(m);
        return m;
    }

    //    public List<OfficeDto> getPhone(){
//        List<Office> m = officerepo.findAll();
//        return m.stream().map( (x) -> modelMapper.map(x, OfficeDto.class)).collect(Collectors.toList());
//
//    }
    public List<OfficeDto> getPhone() {
        List<Office> m = officerepo.findAll();
        return listMapper.mapList(m,OfficeDto.class,modelMapper);

    }

    public OfficeDto getOne(String officeCode) {
        Office m = officerepo.findById(officeCode).orElseThrow(
                () -> new RuntimeException(officeCode + "can not find id !!!"));
        return modelMapper.map(m, OfficeDto.class);

    }


}
