package sit.int204.classicmodels.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodels.entities.Employee;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    List<Employee> findAllByFirstName(String name);

}
