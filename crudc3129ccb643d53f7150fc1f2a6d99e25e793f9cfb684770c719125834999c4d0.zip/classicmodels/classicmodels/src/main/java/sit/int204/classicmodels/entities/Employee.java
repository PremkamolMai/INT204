package sit.int204.classicmodels.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "employees")
@Getter
@Setter

public class Employee {
    @Id
    @Column(name = "employeeNumber", nullable = false)
    private Integer id;

    @Column(name = "lastName", nullable = false, length = 50)
    private String lastname;
    @Column(name = "firstName", nullable = false, length = 50)
    private String firstName;
    @Column(name = "extension", nullable = false, length = 10)
    private String extension;
    @Column(name = "email", nullable = false, length = 100)
    private String email;
    @Column(name = "jobTitle", nullable = false, length = 50)
    private String jobTitle;
    @ManyToOne
    @JoinColumn(name = "reportsTo")
    private Employee reportsTo;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "OfficeCode")
    private Office office;
}
