package sit.int204.classicmodels.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class EmployeeDto {
    private String firstName;
    private String lastname;

    private String officePhone;

    private String officeCountry;
//
//    private OfficeDto office;
}
