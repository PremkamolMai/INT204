package sit.int204.classicmodels.services;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sit.int204.classicmodels.DTO.EmployeeDto;
import sit.int204.classicmodels.DTO.OfficeDto;
import sit.int204.classicmodels.entities.Employee;
import sit.int204.classicmodels.entities.Office;
import sit.int204.classicmodels.repository.EmployeeRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service

public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ModelMapper modelMapper;

    public List<Employee> getName(String name){
        return employeeRepository.findAllByFirstName(name);
    }


    public List<EmployeeDto> find(){
        List<Employee> m = employeeRepository.findAll();
        return m.stream().map( (x) -> modelMapper.map(x, EmployeeDto.class)).collect(Collectors.toList());

    }
}
