package sit.int204.classicmodels.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodels.DTO.OfficeDto;
import sit.int204.classicmodels.entities.Employee;
import sit.int204.classicmodels.entities.Office;
import sit.int204.classicmodels.services.OfficeService;

import java.util.List;

@RestController
@RequestMapping("/api")

public class OfficeController {

    @Autowired
    private OfficeService officeService;

    @GetMapping("/offices")
    public List<Office> selectOffice(){
        return officeService.getAll();
    }
    @GetMapping("/offices/{officeCode}")
    public Office getOfficeById(@PathVariable String officeCode){
        return officeService.getOfficeById(officeCode);
    }

    @GetMapping("offices/{officeCode}/employees")
    public List<Employee> getAllEmployees(@PathVariable String officeCode){
        return officeService.getEmployeeById(officeCode);
    }

    @PostMapping("/offices")
    public Office addOffice(@RequestBody Office office){
        return officeService.addOffice(office);
    }
    @PutMapping("/offices/{officeCode}")
    public Office updateOffice(@PathVariable String officeCode,@RequestBody Office office){
        return officeService.updateOffice(office, officeCode);
    }

    @DeleteMapping("/offices/{officeCode}")
    public Office delectOffice(@PathVariable String officeCode){
        return officeService.delectOffice(officeCode);
    }

    @GetMapping("/offices/dto")
    public List<OfficeDto> getAllPhone(){
        return officeService.getPhone();
    }

    @GetMapping("/offices/dto/{officeCode}")
    public OfficeDto getOne(@PathVariable String officeCode){
        return officeService.getOne(officeCode);
    }
}
