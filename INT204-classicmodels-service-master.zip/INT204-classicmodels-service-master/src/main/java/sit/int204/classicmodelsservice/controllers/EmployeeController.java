package sit.int204.classicmodelsservice.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.dtos.SimpleEmployeeDTO;
import sit.int204.classicmodelsservice.models.Employee;
import sit.int204.classicmodelsservice.models.Office;
import sit.int204.classicmodelsservice.repositories.EmployeeRepository;
import sit.int204.classicmodelsservice.services.EmployeeService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService service;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private EmployeeRepository repository;

//    @GetMapping("")
//    public List<Employee> getEmployees() {
//        return service.getAllEmployees();
//    }

    @GetMapping("/{employeeNumber}")
    public Employee getEmployee(@PathVariable int employeeNumber) {
        return service.getEmployee(employeeNumber);
    }

    @GetMapping("/{employeeNumber}/offices")
    public Office getOfficeFromEmployee(@PathVariable int employeeNumber) {
        return service.getEmployee(employeeNumber).getOffice();
    }

    @GetMapping("/{employeeNumber}/reportsTo")
    public Employee getReportsToFromEmployee(@PathVariable int employeeNumber) {
        return service.getEmployee(employeeNumber).getEmployee();
    }

    @PostMapping("")
    @ResponseStatus(HttpStatus.CREATED)
    public Employee create(@RequestBody Employee newEmployee) {
        return service.addNewEmployee(newEmployee);
    }

    @PutMapping("/{employeeNumber}")
    public Employee updateEmployees(@RequestBody Employee updateEmployee, @PathVariable int
            employeeNumber) {
        if (employeeNumber == updateEmployee.getId()) {
            return service.updateEmployees(employeeNumber, updateEmployee);
        } else {
            throw new RuntimeException("EmployeeNumber is not match !!!");
        }
    }

    @DeleteMapping("/{employeeNumber}")
    public void deleteEmployeesByNumber(@PathVariable int employeeNumber) {
        service.deleteEmployeesByNumber(employeeNumber);
    }
    @GetMapping("")
    public List<SimpleEmployeeDTO> getEmployees() {
        List<Employee> employeeList = repository.findAll();
        return employeeList.stream()
                .map(e -> modelMapper.map(e, SimpleEmployeeDTO.class))
                .collect(Collectors.toList());
    }
//    @GetMapping("")
//    public List<SimpleEmployeeDTO> getEmployees() {
//        List<Employee> employeeList = repository.findAll();
//        return mapList(employeeList, EmployeeOfficeDTO.class, modelMapper);
//    }
}
