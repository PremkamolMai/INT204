package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sit.int204.classicmodelsservice.exeception.ItemNotFoundException;
import sit.int204.classicmodelsservice.models.Employee;
import sit.int204.classicmodelsservice.models.Office;
import sit.int204.classicmodelsservice.repositories.EmployeeRepository;
import sit.int204.classicmodelsservice.repositories.OfficeRepository;

import java.util.List;
import java.util.Set;


@Service
public class OfficeService {
    @Autowired
    private OfficeRepository repository;
    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Office> getAllOffices() {
        return repository.findAll();
    }

    public Office getOffice(String officeCode) {
        return repository.findById(officeCode).orElseThrow(
                () -> new ItemNotFoundException("office Id " + officeCode + " does not exist !!"));
    }

    public Office addNewOffice(Office newOffice) {
//        return service.create(newOffice);
        return repository.saveAndFlush(newOffice);
    }

    public Office update(String officeCode, Office updateOffice) {
        Office office = repository.findById(officeCode).map(o -> mapOffice(o, updateOffice))
                .orElseThrow(() -> new RuntimeException(officeCode + " does not exist !!"));
        return repository.saveAndFlush(office);
    }

    public void deleteOffice(String officeCode) {
        repository.findById(officeCode).orElseThrow(() ->
                new RuntimeException(officeCode + " does not exist !!"));
        repository.deleteById(officeCode);
    }

    private Office mapOffice(Office office, Office updateOffice) {
        office.setCity(updateOffice.getCity());
        office.setPhone(updateOffice.getPhone());
        office.setAddressLine1(updateOffice.getAddressLine1());
        office.setAddressLine2(updateOffice.getAddressLine2());
        office.setState(updateOffice.getState());
        office.setCountry(updateOffice.getCountry());
        office.setPostalCode(updateOffice.getPostalCode());
        office.setTerritory(updateOffice.getTerritory());
        return office;
    }

    public Set<Employee> getEmployeesByOffice(String officeCode) {
        return getOffice(officeCode).getEmployees();
    }

    public Employee insertEmployeeOffice(String officeCode, Employee newEmployee) {
        Office office = getOffice(officeCode);
        newEmployee.setOffice(office);
        return employeeRepository.saveAndFlush(newEmployee);
    }
}
