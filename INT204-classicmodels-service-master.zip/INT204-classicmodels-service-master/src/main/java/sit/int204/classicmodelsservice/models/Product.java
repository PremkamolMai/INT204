package sit.int204.classicmodelsservice.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "products")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class Product {
    @Id
    private String productCode;
    private String productName;
    private String productLine;
    private String productDescription;
    @Column(name = "quantityInstock")
    private Integer quantity;
    @Column(name = "MSRP")
    private Double price;

}
