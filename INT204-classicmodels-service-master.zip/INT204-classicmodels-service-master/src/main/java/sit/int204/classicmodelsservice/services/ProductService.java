package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import sit.int204.classicmodelsservice.exeception.ItemNotFoundException;

import sit.int204.classicmodelsservice.models.Customer;
import sit.int204.classicmodelsservice.models.Employee;
import sit.int204.classicmodelsservice.models.Office;
import sit.int204.classicmodelsservice.models.Product;
import sit.int204.classicmodelsservice.repositories.ProductRepository;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public Product getProductById(String id){
        //int x = Integer.valueOf("A123");
        String x = null;
        x.toLowerCase();
        return productRepository.findById(id).orElseThrow(
                ()-> new RuntimeException("Product id "+ id + "does not exits"));
    }


    public Page<Product> getProductsWithpaging(int page, int size, String sortBy) {
        Sort sort = Sort.by(sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return productRepository.findAll(pageable);
    }

    public List<Product> getProductsQuantity(int quantity) {
        return productRepository.findProductByQuantityGreaterThanEqual(quantity);
    }

    public List<Product> getProductsByNameOrDescription(String name, String description) {
        return productRepository.findProductByProductNameContainingOrProductDescriptionContaining(name, description);
    }

    public List<Product> getProductsByPriceSetween(Double low, Double high) {
        if (low > high) {
//            double tmp = low;
//            low = high;
//            high = tmp;
            return productRepository.findProductByPriceBetweenOrderByPriceDesc(high, low);
        } else {
            return productRepository.findProductByPriceBetweenOrderByPriceDesc(low, high);
        }
    }

    public List<Product> getProductByProductLine(String productLine, int page, int size, String sortBy) {
        Sort sort = Sort.by(sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);

        return productRepository.findProductByProductLine(productLine, pageable);
    }

    public Product addNewProduct(Product newProduct) {
        return productRepository.saveAndFlush(newProduct);
    }

//    public Product updateProduct(String productCode, Product updateProduct) {
//        Product product = productRepository.findById(productCode).map(p -> {
//            p.setProductCode(updateProduct.getProductCode());
//            p.setProductName(updateProduct.getProductName());
//            p.setProductLine(updateProduct.getProductLine());
//            p.setProductDescription(updateProduct.getProductDescription());
//            p.setQuantity(updateProduct.getQuantity());
//            p.setPrice(updateProduct.getPrice());
//            return productRepository.saveAndFlush(p);
//        }).orElseThrow(() -> new ResourceAccessException(productCode + " does not exist !!"));
//        return productRepository.saveAndFlush(product);
//    }
//}

    public Product updateProduct(String productCode, Product updateProduct) {
        Product product = productRepository.findById(productCode).map(p -> mapProduct(p, updateProduct))
                .orElseThrow(() -> new RuntimeException(productCode + " does not exist !!"));
        return productRepository.saveAndFlush(product);
    }

    private Product mapProduct(Product p, Product updateProduct) {
        p.setProductCode(updateProduct.getProductCode());
        p.setProductName(updateProduct.getProductName());
        p.setProductLine(updateProduct.getProductLine());
        p.setProductDescription(updateProduct.getProductDescription());
        p.setQuantity(updateProduct.getQuantity());
        p.setPrice(updateProduct.getPrice());
        return productRepository.saveAndFlush(p);
    }


}


