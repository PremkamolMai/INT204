package sit.int204.classicmodelsservice.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.dtos.SimpleCustomerDTO;
import sit.int204.classicmodelsservice.dtos.SimpleEmployeeDTO;
import sit.int204.classicmodelsservice.models.Customer;
import sit.int204.classicmodelsservice.services.CustomerService;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
        @Autowired

        private CustomerService service;
        @Autowired
        private ModelMapper modelMapper;

        @GetMapping("/{customerNumber}")
        public SimpleCustomerDTO getSimpleCustomerById(@PathVariable Integer customerNumber) {
            return modelMapper.map(service.getCustomerById(customerNumber), SimpleCustomerDTO.class);
        }

    @GetMapping("")
    public List<SimpleCustomerDTO> getCustomers() {
        List<Customer> customersList = service.getCustomers();

        List<SimpleCustomerDTO> customerDTOList = new ArrayList<>(customersList.size());
        for (Customer c : customersList) {
            SimpleCustomerDTO sc = modelMapper.map(c, SimpleCustomerDTO.class);
            customerDTOList.add(sc);
    }

//            List<SimpleCustomerDTO> customersDTOList =
//                    customersList.stream().map(c -> modelMapper.map(c, SimpleCustomerDTO.class)).collect(Collectors.toList());
            return customerDTOList;

        }
}











//    @Autowired
//    private CustomerService service;
//
//    @GetMapping("")
//    public List<Customer> getCustomers() {
//        return service.getAllCustomers();
//    }
//
//    @GetMapping("/{customerNumber}")
//    public Customer getCustomer(@PathVariable int customerNumber) {
//        return service.getCustomer(customerNumber);
//    }
//
//    @PostMapping("")
//    public Customer create(@RequestBody Customer newCustomer) {
//        return service.addNewCustomer(newCustomer);
//    }
//
//    @PutMapping("/{customerNumber}")
//    public Customer update(@RequestBody Customer updateCustomer, @PathVariable int customerNumber) {
//        if (customerNumber == updateCustomer.getId()) {
//            return service.update(customerNumber, updateCustomer);
//        } else {
//            throw new RuntimeException("CustomerNumber is not match !!!");
//        }
//    }
//
//    @DeleteMapping("/{customerNumber}")
//    public void delete(@PathVariable int customerNumber) {
//        service.deleteCustomer(customerNumber);
//    }
//
//
//}
