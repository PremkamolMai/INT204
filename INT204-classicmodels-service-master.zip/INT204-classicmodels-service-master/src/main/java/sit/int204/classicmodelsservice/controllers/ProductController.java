package sit.int204.classicmodelsservice.controllers;

import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelsservice.exeception.ItemNotFoundException;
import sit.int204.classicmodelsservice.models.Office;
import sit.int204.classicmodelsservice.models.Product;
import sit.int204.classicmodelsservice.services.ProductService;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    @Autowired
    private ProductService service;

    @GetMapping("/pages")
    public Page<Product> getProductsPage(
                @RequestParam(defaultValue = "0") Integer page,
                @RequestParam(defaultValue = "10") Integer size,
                @RequestParam(defaultValue = "productCode") String sortBy) {
            return service.getProductsWithpaging(page,size,sortBy);
    }

    @GetMapping("")
    public List<Product> getProducts(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(defaultValue = "productCode") String sortBy) {
        return service.getProductsWithpaging(page, size, sortBy).getContent();
    }
        @GetMapping("/quantity/{quantity}")
    public List<Product> getProducts(@PathVariable Integer quantity){
        return service.getProductsQuantity(quantity);
    }
    @GetMapping("/filters")
    public List<Product> getProductsFilter(@RequestParam String productName,
                                           @RequestParam String productDescription){

        return service.getProductsByNameOrDescription(productName,productDescription);
    }
    @GetMapping("/price/{min}/{max}")
    public List<Product> getProductFilter(@PathVariable Double min,@PathVariable Double max){
        return service.getProductsByPriceSetween(min,max);
    }
    @GetMapping("/{productline}")
    public List<Product> getProductByProductLine(
            @PathVariable String productline,
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(defaultValue = "productLine") String sortBy){
        return service.getProductByProductLine(productline,page,size,sortBy);
    }

    @PutMapping("/{productCode}")
    public Product updateProduct(@RequestBody Product updateProduct,
                                 @PathVariable String productCode) {

        return service.updateProduct(productCode, updateProduct);
    }
    @PostMapping("")
    public Product create(@RequestBody Product newProduct){
        return service.addNewProduct(newProduct);
    }
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable String id){
        return service.getProductById(id);
    }
    @ExceptionHandler(ItemNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ItemNotFoundException handleNoSuchElementFoundException(
            ItemNotFoundException exception) {
        return exception;
    }
    @ExceptionHandler(NumberFormatException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseStatusException handleNumberElementFoundException(RuntimeException exception){
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid number ja"+ exception.getMessage());
    }

    }


//    public Office update(@RequestBody Office updateOffice, @PathVariable String
//            officeCode) {
//        if (officeCode.equals(updateOffice.getId())) {
//            return service.update(officeCode, updateOffice);
//        } else {
//            throw new RuntimeException("OfficeCode is not match !!!");
//        }
    //contain คือเอาข้อมูลที่อยู่ในนั้นมา ไม่ว่าจะตำแหน่งไหน