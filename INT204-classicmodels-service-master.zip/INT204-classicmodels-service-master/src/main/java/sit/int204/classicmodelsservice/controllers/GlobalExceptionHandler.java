package sit.int204.classicmodelsservice.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelsservice.exeception.ItemNotFoundException;

@RestController
public class GlobalExceptionHandler {
    @ExceptionHandler(ItemNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ItemNotFoundException handleNoSuchElementFoundException(
            ItemNotFoundException exception) {
        return exception;
    }
    @ExceptionHandler(NumberFormatException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseStatusException handleNumberElementFoundException(RuntimeException exception){
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid number ja"+ exception.getMessage());
    }
}

