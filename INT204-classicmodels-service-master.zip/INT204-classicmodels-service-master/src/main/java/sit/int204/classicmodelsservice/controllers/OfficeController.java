package sit.int204.classicmodelsservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.models.Employee;
import sit.int204.classicmodelsservice.models.Office;
import sit.int204.classicmodelsservice.services.OfficeService;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/offices")
public class OfficeController {
    @Autowired
    private OfficeService service;

    @GetMapping("")
    public List<Office> getOffices() {
        return service.getAllOffices();
    }

    @GetMapping("/{officeCode}")
    public Office getOffice(@PathVariable String officeCode) {
        return service.getOffice(officeCode);
//                .orElseThrow(
//                ()->new RuntimeException(officeCode+ " does not exist !!!"));;
    }

    @GetMapping("/{officeCode}/employees")
    public Set<Employee> getEmployeesByOffice(@PathVariable String officeCode) {
        return service.getEmployeesByOffice(officeCode);
    }


    @PostMapping("")
    @ResponseStatus(HttpStatus.CREATED)
    public Office create(@RequestBody Office newOffice) {
        return service.addNewOffice(newOffice);
    }

    @PostMapping("/{officeCode}/employees")
    @ResponseStatus(HttpStatus.CREATED)
    public Employee insertEmployeeOffice(@PathVariable String officeCode, @RequestBody Employee newEmployee) {
        return service.insertEmployeeOffice(officeCode, newEmployee);
    }

    @PutMapping("/{officeCode}")
    public Office update(@RequestBody Office updateOffice, @PathVariable String
            officeCode) {
        if (officeCode.equals(updateOffice.getId())) {
            return service.update(officeCode, updateOffice);
        } else {
            throw new RuntimeException("OfficeCode is not match !!!");
        }
//        return service.update(officeCode, updateOffice);
    }

    @DeleteMapping("/{officeCode}")
    public void delete(@PathVariable String officeCode) {
        service.deleteOffice(officeCode);
    }

}

