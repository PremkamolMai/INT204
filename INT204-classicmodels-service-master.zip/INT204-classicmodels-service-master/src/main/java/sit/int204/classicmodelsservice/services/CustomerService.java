package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelsservice.models.Customer;
import sit.int204.classicmodelsservice.models.Employee;
import sit.int204.classicmodelsservice.repositories.CustomerRepository;

import java.util.List;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository repository;
    public Customer getCustomerById(Integer customerId) {
        return repository.findById(customerId).orElseThrow(()->new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Customer id "+ customerId+ "Does Not Exist !!!"));
    }

    public List<Customer> getCustomers() {
        return repository.findAll();

    }
}












//    @Autowired
//    private CustomerRepository repository;
//
//    public List<Customer> getAllCustomers() {
//        return repository.findAll();
//    }
//
//    public Customer getCustomer(int customerNumber) {
//        return repository.findById(customerNumber).orElseThrow(
//                () -> new RuntimeException(customerNumber + " does not exist !!!"));
//    }
//
//    public Customer addNewCustomer(Customer newCustomer) {
//        return repository.saveAndFlush(newCustomer);
//    }
//
//    public Customer update(int customerNumber, Customer updateCustomer) {
//        Customer customer = repository.findById(customerNumber).map(c -> mapCustomer(c, updateCustomer))
//                .orElseThrow(() -> new RuntimeException(customerNumber + " does not exist !!!"));
//        return repository.saveAndFlush(customer);
//    }
//
//    public void deleteCustomer(int customerNumber) {
//        repository.deleteById(customerNumber);
//    }
//
//    private Customer mapCustomer(Customer customer, Customer updateCustomer) {
//        customer.setCustomerName(updateCustomer.getCustomerName());
//        customer.setContactLastName(updateCustomer.getContactLastName());
//        customer.setContactFirstName(updateCustomer.getContactFirstName());
//        customer.setPhone(updateCustomer.getPhone());
//        customer.setAddressLine1(updateCustomer.getAddressLine1());
//        customer.setAddressLine2(updateCustomer.getAddressLine2());
//        customer.setCity(updateCustomer.getCity());
//        customer.setState(updateCustomer.getState());
//        customer.setPostalCode(updateCustomer.getPostalCode());
//        customer.setCountry(updateCustomer.getCountry());
//        customer.setCreditLimit(updateCustomer.getCreditLimit());
//        return customer;
//    }


