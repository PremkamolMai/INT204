package sit.int204.classicmodelsservice.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodelsservice.models.Product;

import java.util.List;


public interface ProductRepository  extends JpaRepository<Product ,String> {
    List<Product> findProductByQuantityGreaterThanEqual(Integer quantity);

    Page<Product> findProductByQuantityGreaterThanEqual(Integer quantity, Pageable pageable);

    List<Product> findProductByProductNameContainingOrProductDescriptionContaining(String name,String description);
    Page<Product> findProductByProductNameContainingOrProductDescriptionContaining(String name,String description,Pageable pageable);

    List<Product> findProductByPriceBetweenOrderByPriceDesc(Double low, Double high);

//    List<Product> findProductByProductLine(String sortBy,String productline);

    List<Product> findProductByProductLine(String productLine, Pageable pageable);

//    List<Product> findProductByProductPut(String productCode, Product updateProduct);
}
