package sit.int204.classicmodelsservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sit.int204.classicmodelsservice.models.Employee;
import sit.int204.classicmodelsservice.repositories.EmployeeRepository;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository repository;

    public List<Employee> getAllEmployees() {
        return repository.findAll();
    } // select * from employee

    public Employee getEmployee(int employeeNumber) {
        return repository.findById(employeeNumber).orElseThrow(
                () -> new RuntimeException(employeeNumber + " does not exist !!"));
    } // select * from employee where employeeId

    public Employee addNewEmployee(Employee newEmployee) {
        return repository.saveAndFlush(newEmployee);
    }

    public Employee updateEmployees(int employeeNumber, Employee updateEmployee) {
        Employee employee = repository.findById(employeeNumber).map(e -> mapEmployee(e, updateEmployee))
                .orElseThrow(() -> new RuntimeException(employeeNumber + " does not exist !!"));
        return repository.saveAndFlush(employee);
    }

    public void deleteEmployeesByNumber(int employeeNumber) {
        repository.deleteById(employeeNumber);
    }

    private Employee mapEmployee(Employee employee, Employee updateEmployee) {
        employee.setFirstName(updateEmployee.getFirstName());
        employee.setLastName(updateEmployee.getLastName());
        employee.setExtension(updateEmployee.getExtension());
        employee.setEmail(updateEmployee.getEmail());
        employee.setJobTitle(updateEmployee.getJobTitle());
        return employee;
    }

}



